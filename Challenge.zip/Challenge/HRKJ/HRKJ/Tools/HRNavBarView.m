//
//  HRNavBarView.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/28.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRNavBarView.h"

@implementation HRNavBarView


-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
//        UIView *bg=[[UIView alloc]initWithFrame:CGRectMake(0, 0, Swidth, 20)];
//        bg.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.9];
//        [self addSubview:bg];
        
        self.frame=CGRectMake(0, 20, Swidth, 44);
        self.barTintColor=[UIColor blackColor];
        
        
        
    }
    
    
    
    
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
