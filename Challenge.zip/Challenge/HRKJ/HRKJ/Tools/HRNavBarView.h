//
//  HRNavBarView.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/28.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HRNavBarView : UINavigationBar




@end
