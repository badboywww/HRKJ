//
//  HRBaseViewController.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRBaseViewController.h"

@interface HRBaseViewController (){
    UITableView *TableView;
}

@end

@implementation HRBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self SetNav];
}

-(void)SetNav{
    UIView *bg=[[UIView alloc]initWithFrame:CGRectMake(0, 0, Swidth, 20)];
    bg.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.9];
    [self.view addSubview:bg];
    
    UINavigationBar *NavBar=[[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, Swidth, 44)];
    NavBar.barTintColor=[UIColor blackColor];
    
    UINavigationItem *NavItem=[[UINavigationItem alloc]init];
    
    
    UILabel *TitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(NavBar.center.x, 20, 100, 20)];
    TitleLabel.textAlignment = 1;
    TitleLabel.textColor=[UIColor whiteColor];
    TitleLabel.font=[UIFont systemFontOfSize:15];
    
    NavItem.titleView=TitleLabel;
    
//    // 创建左侧按钮
//        UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"leftButton" style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
//        leftButton.tintColor = [UIColor purpleColor];
//
//    // 创建右侧按钮
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Other"] style:UIBarButtonItemStylePlain target:self action:@selector(setOther)];
//    rightButton.tintColor = [UIColor whiteColor];
//
//    // 添加左侧、右侧按钮
//    [NavItem setLeftBarButtonItem:leftButton animated:false];
//    [NavItem setRightBarButtonItem:rightButton animated:false];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    [NavBar pushNavigationItem:NavItem animated:false];
    [self.view addSubview:NavBar];
}
-(void)setUI{
    
    TableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, Swidth, Sheight-64) style:UITableViewStyleGrouped];
    
    TableView.delegate=self;
    TableView.dataSource=self;
    TableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    TableView.showsVerticalScrollIndicator=NO;
   
    [self.view addSubview:TableView];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
