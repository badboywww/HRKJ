//
//  HRLoginViewController.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/28.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRLoginViewController.h"

@interface HRLoginViewController ()

@end

@implementation HRLoginViewController

+(id)share{
    static HRLoginViewController *login=nil;
    if (login == nil) {
        login = [HRLoginViewController new];
    }
    return login;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUI];
    
    self.title=@"登陆";
    
}

-(void)setUI{
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    UIButton *Btn=[UIButton buttonWithType:UIButtonTypeSystem];
    Btn.frame=CGRectMake(Swidth/2-50, Sheight/2-15, 100, 30);
    [Btn setTitle:@"Next" forState:UIControlStateNormal];
    [Btn addTarget:self action:@selector(Next) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:Btn];
    
    
}
-(void)Next{
    
    self.mainVc=[MainViewController shareObject];
    self.mainVc.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"主页" image:[[UIImage imageNamed:@"Main"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"Main_Selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    self.mainVc.tabBarItem.tag=0;
    
    self.PerVc=[PersonalViewController new];
    self.PerVc.tabBarItem=[[UITabBarItem alloc]initWithTitle:@"个人" image:[[UIImage imageNamed:@"Me"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"Me_Selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    self.PerVc.tabBarItem.tag=0;
    
    self.TabarVC=[UITabBarController new];
    self.TabarVC.viewControllers=@[self.mainVc,self.PerVc];
    self.TabarVC.selectedIndex=0;
    self.TabarVC.tabBar.tintColor=UIColorFromHex(0x20B2AA);
    
    NSMutableDictionary *attrnor = [NSMutableDictionary dictionary];
    attrnor[NSFontAttributeName] = [UIFont systemFontOfSize:15];
    [self.tabBarItem setTitleTextAttributes:attrnor forState:0];
    [self.navigationController pushViewController:self.TabarVC animated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
