//
//  HRLoginViewController.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/28.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "PersonalViewController.h"
@interface HRLoginViewController : UIViewController


@property (strong, nonatomic) UITabBarController *TabarVC;

@property(strong,nonatomic)MainViewController *mainVc;
@property(strong,nonatomic)PersonalViewController *PerVc;

+ (id)share;

@end
