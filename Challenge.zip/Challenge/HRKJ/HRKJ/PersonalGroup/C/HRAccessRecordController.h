//
//  HRAccessRecordController.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRTwoCell.h"
#import "HRAccessRecordModel.h"
@interface HRAccessRecordController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@end
