//
//  HRAccessRecordController.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRAccessRecordController.h"

@interface HRAccessRecordController ()
{
    UITableView *TableView;
    NSArray *TitleArray;
}

@end

@implementation HRAccessRecordController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self SetNav];
    [self setUI];
    [self setLoadData];
    
}

-(void)SetNav{
    UIView *bg=[[UIView alloc]initWithFrame:CGRectMake(0, 0, Swidth, 20)];
    bg.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.9];
    [self.view addSubview:bg];
    
    UINavigationBar *NavBar=[[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, Swidth, 44)];
    NavBar.barTintColor=[UIColor blackColor];
    
    UINavigationItem *NavItem=[[UINavigationItem alloc]init];
    
    
    UILabel *TitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(NavBar.center.x, 20, 100, 20)];
    TitleLabel.text=@"访问记录";
    TitleLabel.textAlignment = 1;
    TitleLabel.textColor=[UIColor whiteColor];
    TitleLabel.font=[UIFont systemFontOfSize:15];
    
    NavItem.titleView=TitleLabel;
    
    // 创建左侧按钮
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"left"] style:UIBarButtonItemStylePlain target:self action:@selector(Back)];
     leftButton.tintColor = [UIColor whiteColor];
    
    // 创建右侧按钮
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(Edit)];
    rightButton.tintColor = [UIColor whiteColor];
    
    // 添加左侧、右侧按钮
    [NavItem setLeftBarButtonItem:leftButton animated:false];
    [NavItem setRightBarButtonItem:rightButton animated:false];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    [NavBar pushNavigationItem:NavItem animated:false];
    [self.view addSubview:NavBar];
}

-(void)Back{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)Edit{
}

-(void)setUI{
    
    TableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, Swidth, Sheight-64) style:UITableViewStyleGrouped];
    
    TableView.delegate=self;
    TableView.dataSource=self;
    TableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    TableView.showsVerticalScrollIndicator=NO;
    [TableView registerNib:[UINib nibWithNibName:@"HRTwoCell" bundle:nil] forCellReuseIdentifier:@"TwoCell"];
    [self.view addSubview:TableView];
    
    
    
}
-(void)setLoadData{
    

    
}
#pragma make TableView
- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 20;
    
}

- (UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    HRTwoCell *cell=[tableView dequeueReusableCellWithIdentifier:@"TwoCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    HRAccessRecordModel *model=[HRAccessRecordModel new];
    [cell setProperty:model];
    
   
    cell.OneText.text=[NSString stringWithFormat:@"%lu号访客",indexPath.row+1];
 
    
    return cell;
}

- (CGFloat)tableView:(nonnull UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return 64.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
