//
//  HRInformationController.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRInformationController.h"

@interface HRInformationController ()
{
    UITableView *PersonalTable;
    NSArray *TitleArray;
}

@end

@implementation HRInformationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self SetNav];
    [self setUI];
    [self setLoadData];
}
-(void)SetNav{
    UIView *bg=[[UIView alloc]initWithFrame:CGRectMake(0, 0, Swidth, 20)];
    bg.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.9];
    [self.view addSubview:bg];
    
    UINavigationBar *NavBar=[[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, Swidth, 44)];
    NavBar.barTintColor=[UIColor blackColor];
    
    UINavigationItem *NavItem=[[UINavigationItem alloc]init];
    
    
    UILabel *TitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(NavBar.center.x, 20, 100, 20)];
    TitleLabel.text=@"个人信息";
    TitleLabel.textAlignment = 1;
    TitleLabel.textColor=[UIColor whiteColor];
    TitleLabel.font=[UIFont systemFontOfSize:15];
    
    NavItem.titleView=TitleLabel;
    
    // 创建左侧按钮
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"left"] style:UIBarButtonItemStylePlain target:self action:@selector(Back)];
    leftButton.tintColor = [UIColor whiteColor];
    
    // 创建右侧按钮
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Other"] style:UIBarButtonItemStylePlain target:self action:@selector(setOther)];
//    rightButton.tintColor = [UIColor whiteColor];
    
    // 添加左侧、右侧按钮
     [NavItem setLeftBarButtonItem:leftButton animated:false];
 //   [NavItem setRightBarButtonItem:rightButton animated:false];
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    [NavBar pushNavigationItem:NavItem animated:false];
    [self.view addSubview:NavBar];
}
-(void)Back{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)setUI{
    
    PersonalTable=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, Swidth, Sheight-64) style:UITableViewStyleGrouped];
    
    PersonalTable.delegate=self;
    PersonalTable.dataSource=self;
    PersonalTable.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    PersonalTable.showsVerticalScrollIndicator=NO;
    [PersonalTable registerNib:[UINib nibWithNibName:@"HRHeadCell" bundle:nil] forCellReuseIdentifier:@"HeadCell"];
    [PersonalTable registerNib:[UINib nibWithNibName:@"HROnewCell" bundle:nil] forCellReuseIdentifier:@"OneCell"];
    [self.view addSubview:PersonalTable];
    
    
    
}


-(void)setLoadData{
    
    //第二组Title:
    TitleArray=@[@"头像",@"昵称",@"账号",@"我的二维码",@"更多"];
    
    
    
    
}


//返回分组数：
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

//返回每组行数：
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section ==0) {
        return TitleArray.count;
    }else {
        return 1;
    }
}

//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if(indexPath.row == 0){
            return 115.f;
        }else{
            return 44.f;
        }
        
    }
    return 44.f;
}


//点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0){
        if (indexPath.row == 0) {
            HRHeadCell *cell=[tableView dequeueReusableCellWithIdentifier:@"HeadCell"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.LeftLabel.text=TitleArray[indexPath.row];
            cell.HeadImg.image=[UIImage imageNamed:@"headimg"];
            return cell;
        }else{
            HROnewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"OneCell"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.OneLabel.text=TitleArray[indexPath.row];
            cell.RightText.hidden=YES;
            return cell;
        }
    }else{
        HROnewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"OneCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.OneLabel.text=@"地址";
        cell.RightText.hidden=YES;
        return cell;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
