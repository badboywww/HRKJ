//
//  PersonalViewController.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/26.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "PersonalViewController.h"

@interface PersonalViewController ()
{
    UITableView *PersonalTable;
    NSArray *TitleArray;
    
    
}

@end

@implementation PersonalViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor=[UIColor whiteColor];
    
   [self SetNav];
   [self setUI];
   [self setLoadData];
    
}

-(void)SetNav{
    UIView *bg=[[UIView alloc]initWithFrame:CGRectMake(0, 0, Swidth, 20)];
    bg.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.9];
    [self.view addSubview:bg];
    
    UINavigationBar *NavBar=[[UINavigationBar alloc]initWithFrame:CGRectMake(0, 20, Swidth, 44)];
    NavBar.barTintColor=[UIColor blackColor];

    UINavigationItem *NavItem=[[UINavigationItem alloc]init];

    
    UILabel *TitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(NavBar.center.x, 20, 100, 20)];
    TitleLabel.text=@"个人中心";
    TitleLabel.textAlignment = 1;
    TitleLabel.textColor=[UIColor whiteColor];
    TitleLabel.font=[UIFont systemFontOfSize:15];
    
    NavItem.titleView=TitleLabel;

    // 创建左侧按钮
//    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"leftButton" style:UIBarButtonItemStylePlain target:self action:@selector(leftButtonClick)];
//    leftButton.tintColor = [UIColor purpleColor];

    // 创建右侧按钮
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Other"] style:UIBarButtonItemStylePlain target:self action:@selector(setOther)];
        rightButton.tintColor = [UIColor whiteColor];
    
    // 添加左侧、右侧按钮
  //  [NavItem setLeftBarButtonItem:leftButton animated:false];
    [NavItem setRightBarButtonItem:rightButton animated:false];

    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;

    [NavBar pushNavigationItem:NavItem animated:false];
    [self.view addSubview:NavBar];
}

-(void)setOther{
    HRAccessRecordController *vc=[[HRAccessRecordController alloc]init];
    
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)setUI{
    
    PersonalTable=[[UITableView alloc]initWithFrame:CGRectMake(0, 64, Swidth, Sheight-64) style:UITableViewStyleGrouped];
    
    PersonalTable.delegate=self;
    PersonalTable.dataSource=self;
    PersonalTable.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    PersonalTable.showsVerticalScrollIndicator=NO;
    [PersonalTable registerNib:[UINib nibWithNibName:@"HRHeadImgCell" bundle:nil] forCellReuseIdentifier:@"Head"];
    [PersonalTable registerNib:[UINib nibWithNibName:@"HROnewCell" bundle:nil] forCellReuseIdentifier:@"OneCell"];
    [self.view addSubview:PersonalTable];
    
 
    
}


-(void)setLoadData{
    
    //第二组Title:
    TitleArray=@[@"设置功能一:",@"设置功能二:",@"设置功能三:",@"设置功能四:",@"设置功能五:"];
    
    
    
    
}


//返回分组数：
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

//返回每组行数：
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section ==0) {
        return 1;
    }else {
        return TitleArray.count;
    }
}

//行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 100.f;
    }
    return 44.f;
}


//点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        HRInformationController *vc=[[HRInformationController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0){
        HRHeadImgCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Head"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        HRHeadModel *model=[HRHeadModel new];
        
        [cell setProperty:model];
        
        return cell ;
    }else{
        HROnewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"OneCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.OneLabel.text=TitleArray[indexPath.row];
        cell.RightText.hidden=YES;
        return cell;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
