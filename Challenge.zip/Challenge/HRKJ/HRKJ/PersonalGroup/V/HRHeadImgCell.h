//
//  HRHeadImgCell.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRHeadModel.h"
@interface HRHeadImgCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *HeadImg;
@property (weak, nonatomic) IBOutlet UILabel *NickName;
@property (weak, nonatomic) IBOutlet UILabel *AccountLabel;
@property (weak, nonatomic) IBOutlet UILabel *AccountText;
@property (weak, nonatomic) IBOutlet UIImageView *QRcodeImg;
@property (weak, nonatomic) IBOutlet UIImageView *RightImg;



- (void)setProperty:(HRHeadModel *)model;

@end
