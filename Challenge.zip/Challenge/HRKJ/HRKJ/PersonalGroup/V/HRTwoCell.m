//
//  HRTwoCell.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRTwoCell.h"

@implementation HRTwoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
}

-(void)setProperty:(HRAccessRecordModel *)model{
    self.Onelabel.text=@"访问人:";

    
    self.TweLabel.text=@"访问时间:";
    self.TwoText.text=@"2018-01-28 17:52:55";
    
    /*
    self.OneText.text=model.AccessRecordName;
    self.TwoText.text=model.AccessRecordTime;
    */
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
