//
//  HROnewCell.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HROnewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *OneLabel;
@property (weak, nonatomic) IBOutlet UIImageView *RightImg;
@property (weak, nonatomic) IBOutlet UILabel *RightText;

@end
