//
//  HRHeadImgCell.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRHeadImgCell.h"

@implementation HRHeadImgCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setProperty:(HRHeadModel *)model{
    
    self.HeadImg.image=[UIImage imageNamed:@"headimg"];
    self.NickName.text=@"昵称";
    self.AccountLabel.text=@"账号:";
    self.AccountText.text=@"1234567890";
    self.QRcodeImg.image=[UIImage imageNamed:@"QRcode"];
    
    /*
    self.NickName.text=model.NickName;
    self.AccountText.text=model.Account;
    */
    
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
