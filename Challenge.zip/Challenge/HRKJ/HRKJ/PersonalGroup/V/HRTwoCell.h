//
//  HRTwoCell.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRAccessRecordModel.h"
@interface HRTwoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *Onelabel;
@property (weak, nonatomic) IBOutlet UILabel *OneText;
@property (weak, nonatomic) IBOutlet UILabel *TweLabel;
@property (weak, nonatomic) IBOutlet UILabel *TwoText;

- (void)setProperty:(HRAccessRecordModel *)model;
@end
