//
//  HRAccessRecordModel.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HRAccessRecordModel : NSObject

/*
 AccessRecordName 访问人
 AccessRecordTime 访问时间
*/
@property(strong,nonatomic)NSString *AccessRecordName;
@property(strong,nonatomic)NSString *AccessRecordTime;

@end
