//
//  HRHeadModel.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HRHeadModel : NSObject

/*
 HeadImg 头像
 NickName 昵称
 Account  账号

*/
@property(strong,nonatomic)NSString *NickName;
@property(strong,nonatomic)NSString *HeadImg;
@property(strong,nonatomic)NSString *Account;
@end
