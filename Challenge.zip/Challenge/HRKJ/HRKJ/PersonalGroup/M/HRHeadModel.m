//
//  HRHeadModel.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRHeadModel.h"

@implementation HRHeadModel

-(void)setNickName:(NSString *)NickName{
    if ([NickName isKindOfClass:[NSNull class]]) {
        _NickName = @"暂无";
    }else{
        _NickName = NickName;
    }
}

-(void)setHeadImg:(NSString *)HeadImg{
    if ([HeadImg isKindOfClass:[NSNull class]]) {
        _HeadImg = @"暂无";
    }else{
        _HeadImg = HeadImg;
    }
}

-(void)setAccount:(NSString *)Account{
    if ([Account isKindOfClass:[NSNull class]]) {
        _Account = @"暂无";
    }else{
        _Account = Account;
    }
}


@end
