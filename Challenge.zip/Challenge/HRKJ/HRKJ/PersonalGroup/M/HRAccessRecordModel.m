//
//  HRAccessRecordModel.m
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/29.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import "HRAccessRecordModel.h"

@implementation HRAccessRecordModel
-(void)setAccessRecordName:(NSString *)AccessRecordName{
    if ([AccessRecordName isKindOfClass:[NSNull class]]) {
        _AccessRecordName = @"暂无";
    }else{
        _AccessRecordName = AccessRecordName;
    }
}

-(void)setAccessRecordTime:(NSString *)AccessRecordTime{
    if ([AccessRecordTime isKindOfClass:[NSNull class]]) {
        _AccessRecordTime = @"暂无";
    }else{
        _AccessRecordTime = AccessRecordTime;
    }
}

@end
