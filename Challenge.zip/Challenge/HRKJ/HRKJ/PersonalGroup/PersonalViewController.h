//
//  PersonalViewController.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/26.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HRHeadModel.h"
#import "HRHeadImgCell.h"
#import "HROnewCell.h"
#import "HRAccessRecordController.h"
#import "HRInformationController.h"
@interface PersonalViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@end
