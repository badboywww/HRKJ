//
//  AppDelegate.h
//  HRKJ
//
//  Created by Mr.Wang on 2018/1/25.
//  Copyright © 2018年 Mr.GBLW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

